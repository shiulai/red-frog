﻿using System;

namespace BlackScholesEquation
{
    class EuropeanOption
    {
        private double N, sigma2;
        private double d1, d2, tYrs, sd;
        private double Nd1, Nd2, NnegD2, NnegD1;
        private double p1, p2;

        public double ValueP;
        public double DeltaP;
        public double ThetaP;
        public double GammaP;
               
        public EuropeanOption(double S, double K, double r,
            double sigma, double T)
        {
            // S = underlying asset price (stock price)
            // X = exercise price
            // r = risk free interst rate
            // sigma = standard deviation of underlying asset (stock)
            // t = current date
            // T = maturity date

            sigma2 = sigma * sigma;
            tYrs = T;
            N = 1.0 / Math.Sqrt(2.0 * Math.PI * sigma2);
            sd = Math.Sqrt(tYrs);
            d1 = (Math.Log(S / K) + (r + 0.5 * sigma2) * tYrs) / (sigma * sd);
            d2 = d1 - sigma * sd;
            Nd1 = Utils.CDF(d1);
            Nd2 = Utils.CDF(d2);
            NnegD2 = Utils.CDF(-d2);
            NnegD1 = Utils.CDF(-d1);

            double c = S * Nd1 - K * Math.Exp(-r * tYrs) * Nd2;
            double p = Math.Max(0,K * Math.Exp(-r * tYrs) * NnegD2 - S * NnegD1);

            ValueP = p;

            DeltaP = Nd1 - 1;
            GammaP = Utils.PDF(d1) / (S * sigma * Math.Sqrt(tYrs));
            ThetaP = -1 * ((S * Utils.PDF(d1) * sigma) / 2 * Math.Sqrt(tYrs)) + r * K * Math.Exp(-r * tYrs) * NnegD2;
        }
    }
}