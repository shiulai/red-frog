﻿// reproduce the calculator found
// http://www.money-zine.com/calculators/investment-calculators/black-scholes-calculator/
// using the equations in
// http://finance.bi.no/~bernt/gcc_prog/algoritms_v1/algoritms/node8.html

using System;
using System.Text;
using System.Windows.Forms;

namespace BlackScholesEquation
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double c, p;
                double S = double.Parse(textBox1.Text);
                double X = double.Parse(textBox2.Text);
                double r = double.Parse(textBox3.Text);
                double s = double.Parse(textBox4.Text);
                double t = double.Parse(textBox5.Text);

                var tY = t / 365;

                EuropeanOption ec = new EuropeanOption(S, X, r * 0.01, s, tY);

                textBox6.Clear();

                var result = $@"Valuations
----------
Put PV   = {ec.ValueP}

Greeks (Put)
------------
Put Theta= {ec.ThetaP}
Put Delta= {ec.DeltaP}
Put Gamma= {ec.GammaP}
";

                var step = 0.1;
                int steps = 10;
                int initial = -1 * steps / 2;
                var _risks = new StringBuilder();
                for (int i = initial; i < steps; i++)
                {
                    var _s = X + step * i;
                    var _ec = new EuropeanOption(_s, X, r * 0.01, s, t);
                    _risks.Append($"{_s},{ec.ValueP},{_ec.DeltaP},{_ec.GammaP},{_ec.ThetaP}\r\n");
                }

                var _timeChg = new StringBuilder();
                for (int i = 30; i > 0; i--)
                {

                    var _ec = new EuropeanOption(S, X, r * 0.01, s, (double)i/365);
                    _timeChg.Append($"{i},{ec.ValueP},{_ec.DeltaP},{_ec.GammaP},{_ec.ThetaP}\r\n");
                }

textBox6.Text = $@"{result}

S plots (Put)
-------------
S,p,delta,gamma,theta
{_risks}

T plots (Put)
-------------
T,p,delta,gamma,theta
{_timeChg}";

                    

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Warning",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double S = double.Parse(textBox1.Text);
            double X = double.Parse(textBox2.Text);
            double r = double.Parse(textBox3.Text);
            double s = double.Parse(textBox4.Text);
            double t = double.Parse(textBox5.Text);

            var _units = 1000000;
            var _initLongPos = _units * S;
            
            double st = S;

            EuropeanOption ec = new EuropeanOption(S, X, r * 0.01, s, (double)t/365);

            var contracts = Math.Abs(_units / ec.DeltaP);

            string output = $@"Hedging Simulation
Day,Price,Units,Value,P/L,Put,Delta,Contracts,Value,P/L,Nett
30,{st},{_units},{st * _units },{st * _units - _initLongPos},{ec.ValueP},{ec.DeltaP},{contracts},{ec.ValueP*contracts},0,0
";


            Random ran = new Random();

            for (int i = 29; i >=0; i--)
            {
                double rDouble = ran.Next(200);
                int sign = ran.Next(2) > 1 ? 1 : -1;

                var _return = 1+ (rDouble / 10000 * sign);

                st = S * _return;

                EuropeanOption ec2 = new EuropeanOption(st, X, r * 0.01, s, (double)i/365);

output += $@"{i},{st},{_units},{st * _units },{st * _units - _initLongPos},{ec2.ValueP},{ec2.DeltaP},{contracts},{ec2.ValueP*contracts},{(ec2.ValueP - ec.ValueP) * contracts},{i}
"; 


            }

            textBox6.Text = output;

        }
    }
}
