﻿using System;
namespace BlackScholesEquation
{
    static class Utils
    {
        // Translated from Pascal code found in Wikipedia article
        // https://en.wikipedia.org/wiki/Normal_distribution#Cumulative_distribution_function

        public static double CDF(double x)
        {
            double sum = x, val = x;

            for (int i = 1; i <= 100; i++)
            {
                val *= x * x / (2.0 * i + 1.0);
                sum += val;
            }

            return 0.5 + (sum / Math.Sqrt(2.0 * Math.PI)) * Math.Exp(-(x * x) / 2.0);
        }

        public static double PDF(double x)
        {
            return (1 / Math.Sqrt(2.0 * Math.PI)) * Math.Exp(-(x * x) / 2.0);
        }
    }
}